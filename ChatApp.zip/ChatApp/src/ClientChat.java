import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class ClientChat extends Application implements EventHandler<ActionEvent>{
    private ServerSocket server;
    private Socket socket;
    private BufferedReader br;
    private PrintWriter pw; 
    ////Constructor
    public ClientChat(){
    try{
           System.out.println("Sending Request to server");
            socket = new Socket("localhost",7777);
            System.out.println("Connection done.");
            br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            pw = new PrintWriter(socket.getOutputStream());
            
            startReading();//Method to read all the messages.
            startWriting();//Methond to Write messages.
        }catch(Exception ex){ex.printStackTrace();}
    }
    // Creating the startReading method();
    public void startReading(){
    // Thread - for reading all the data.
        Runnable r1 = ()->{
            System.out.println("Reader Started...");
            
            while(true)
            {
                try {
                    String msg = br.readLine();
                    if(msg.equals("exit")){
                        System.out.println("Server terminated the chat.");
                        break;
                    }
                   // System.out.println("Server "+ msg);
                   tArea.appendText(msg);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
           
         };
        new Thread(r1).start();   
    }
    //Creating the startWriting method.
    public void startWriting(){
        //Thread - for Writting all the data.
        Runnable r2 =()->{
        while(true){
            try
            {
                BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
                String content = br1.readLine();
                pw.println(content);
                pw.flush();
            } catch(Exception ex)
            {
                ex.printStackTrace();
            }
          }
        };
        new Thread(r2).start();
    }    
/*=========================== CREATING THE GUI INTERFACE ============================================*/
    Label title = new Label("Chat App 2.0");//Title for the Chat
    TextArea tArea = new TextArea();//TextArea for to dislplay the messages.
    TextField tfield = new TextField();//TextField to write messages.
    Button btnSend = new Button("Send");// Button send .
    @Override
    public void start(Stage primaryStage) {
      FlowPane fPane1 = new FlowPane();//Creating a FlowPane Layout.
      fPane1.getChildren().add(title);//Adding the title to the Flowpane.
      title.setFont(Font.font("Verdana",FontWeight.BOLD,FontPosture.REGULAR,15)); // Stylizing the Title
      fPane1.setAlignment(Pos.CENTER);
      //Creating another FlowPane for the TextArea.
      FlowPane fPane2 = new FlowPane();
      fPane2.getChildren().add(tArea);
      tArea.setEditable(false);
      //Creating a GridPane Layout for the Textfield and the send button.
      GridPane gPane = new GridPane();
      gPane.setAlignment(Pos.CENTER);
      gPane.add(tArea, 0, 0);
      gPane.add(btnSend, 1, 1);
      gPane.add(tfield, 0, 1);
      gPane.setVgap(8);
      gPane.setHgap(4);
      //Registering the Send Button
      btnSend.setOnAction(this);
      //Creating a BorderPane to organize evetything.
      BorderPane bPane = new BorderPane();
      bPane.setTop(fPane1);
      bPane.setCenter(gPane);
      Scene scene = new Scene(bPane,700, 500);
      primaryStage.setScene(scene);
      primaryStage.setTitle("ClientChat");
      primaryStage.show();
      startReading();
      startWriting();
      
    }

    public static void main(String[] args) {
        launch(args);
        ClientChat chat = new ClientChat();
        
    }
// Event Handler for the send Button.
    public void handle(ActionEvent event) {
        if(event.getSource()== btnSend){
          String contentToSend = tfield.getText();
           pw.println(contentToSend);
           tArea.appendText("Client: "+ contentToSend + "\n");
           tfield.clear();
           tfield.requestFocus();
        }
    }
    
}
